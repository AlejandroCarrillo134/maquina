package com.rentamaquina.maquinaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaquinariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
